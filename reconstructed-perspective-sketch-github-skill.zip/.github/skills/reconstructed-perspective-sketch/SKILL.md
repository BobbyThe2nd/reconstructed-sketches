---
name: reconstructed-perspective-sketch
description: >
  Transform uploaded photographs of buildings, furniture, vehicles, tools, interiors,
  and everyday objects into simplified hand-drawn observational sketches using
  deliberately unconventional perspective, geometric abstraction, visible construction
  lines, graphite-like contours, restrained colored-pencil palettes, and generous
  negative space. Use this skill when the user asks to reinterpret a photo as an
  architectural, industrial-design, or observational drawing with intentionally
  inconsistent spatial logic rather than realistic perspective.
---

# Reconstructed Perspective Sketch

## Purpose

Use this skill to reinterpret a supplied reference image as a hand-drawn observational
study.

The goal is not to reproduce the photograph faithfully. The goal is to preserve the
identity and essential structure of the subject while rebuilding its geometry through an
intentionally unconventional spatial system.

The result should feel like a careful drawing made by someone who has observed the
subject closely, simplified it into structural forms, and then reconstructed space using
a personal visual logic rather than conventional photographic perspective.

This is a visual-language specification. Do not reference or imitate any named living
artist. Follow the rules below directly.

---

# Core Outcome

The transformed image should:

- remain immediately recognizable as the same subject
- simplify complex forms into clear geometric volumes
- avoid strict one-point, two-point, or three-point perspective
- allow multiple conflicting projection systems within one object
- use hand-drawn graphite-like outlines
- retain subtle construction and alignment lines
- reduce fine detail
- use muted low-saturation color or monochrome tonal treatment
- preserve visible paper and pencil texture
- use minimal environmental background
- feel observational, architectural, quiet, and constructed rather than photorealistic

The viewer should have the impression:

> I know exactly what this object is, but the space around and inside it behaves in an
> unusual way.

---

# Priority Order

When any rules conflict, preserve them in this order:

1. Subject recognizability
2. Structural geometry
3. Unconventional spatial construction
4. Hand-drawn character
5. Geometric simplification
6. Restrained palette
7. Paper-and-pencil texture
8. Fine detail

Never destroy the identity of the subject simply to increase distortion.

Never make the geometry so chaotic that the object becomes abstract or cubist unless the
user explicitly requests stronger abstraction.

---

# Workflow

Follow this sequence whenever an image is supplied.

## Phase 1 — Read the Source Image

Identify:

- the primary subject
- the subject silhouette
- the dominant mass
- secondary masses
- major planes
- major openings
- repeated elements
- parts essential to recognition
- parts that may be safely removed
- the approximate orientation of the subject
- which surfaces are most useful for communicating form

Do not begin by copying small details.

Think structurally first.

---

# Subject Analysis by Category

## Buildings

Identify:

- main building mass
- front facade
- side facade
- roof geometry
- visible extensions
- entrances
- major vertical divisions
- window rhythm
- floor rhythm
- balconies or projecting masses
- chimneys or rooftop elements
- unusual silhouette features

Treat windows primarily as repeated modules rather than individual photoreal objects.

Do not reproduce every brick, trim element, reflection, sign, crack, or material joint.

## Furniture

Identify:

- primary body volume
- top plane
- front plane
- side plane
- legs or supports
- openings
- drawers
- shelves
- seat/back relationships
- repeated structural members

Reduce upholstery and curved surfaces to simple planes when possible.

## Vehicles

Identify:

- main body mass
- cabin
- hood or front volume
- cargo volume if present
- wheel placement
- windshield plane
- major side panels
- front/rear orientation

Simplify body curvature into wedges, boxes, and broad planes.

Do not emphasize brand logos, panel seams, grille detail, or tiny lights unless they are
essential to recognition.

## Tools and Everyday Objects

Identify:

- dominant body
- handle
- support
- opening
- moving or attached components
- major material boundaries
- primary silhouette

If the object is complex, preserve the overall proportion and functional relationships
while reducing minor mechanisms.

## Interiors

Identify:

- major room planes
- floor
- ceiling
- primary walls
- dominant furniture
- major openings
- repeated architectural elements

Do not reproduce full realistic room depth. Reconstruct the room as a set of planes that
may follow different projection rules.

---

# Phase 2 — Reduce the Subject to Geometric Primitives

Convert the source into a small number of dominant forms.

Preferred primitives:

- cuboids
- rectangular prisms
- wedges
- trapezoidal prisms
- flat planes
- cylinders
- simplified cones
- simple arches
- broad curved surfaces only when structurally necessary

Use as few forms as possible while preserving recognizability.

## Simplification Rule

When deciding whether to preserve a feature, ask:

1. Does it define the silhouette?
2. Does it reveal function?
3. Does it establish scale?
4. Does it create a recognizable repeated rhythm?
5. Is it visually dominant?

If the answer to all five is no, simplify or omit it.

---

# Phase 3 — Reconstruct Perspective

## Central Rule

Do not automatically preserve photographic perspective.

Do not force the entire scene into a single mathematically consistent projection.

Instead, treat each major plane or volume as capable of having its own spatial behavior.

---

# Allowed Perspective Behaviors

You may use any controlled combination of the following:

- multiple vanishing points
- incompatible vanishing points
- vanishing points inside the image
- vanishing points near the subject
- vanishing points that appear to sit in front of the subject
- weak or absent convergence
- parallel depth edges
- converging edges on one plane and diverging edges on another
- near elements slightly smaller than distant equivalents
- distant planes slightly enlarged
- depth compression
- depth expansion
- independent plane rotation
- slight facade bending
- asymmetric scale changes
- unequal left/right depth
- inconsistent roof projection
- repeated elements that grow slightly with distance
- repeated elements that shrink less than expected
- object faces drawn almost orthographically while adjacent faces remain perspective-like

---

# Near-Small / Far-Large Rule

This is an important optional spatial device.

In selected regions, invert normal perspective subtly:

- a nearer face may be slightly narrower than a farther face
- repeated windows may grow slightly toward the distance
- a roof plane may widen away from the viewer
- a table or cabinet may expand toward the rear
- distant architectural bays may become marginally larger

Use this selectively.

Do not scale distant elements so aggressively that the object appears broken.

Recommended strength:

- subtle by default
- medium when the user asks for stronger distortion
- extreme only when explicitly requested

---

# Plane Independence Rule

Adjacent planes do not need to share a single vanishing system.

Example:

- front facade: nearly orthographic
- side facade: slightly divergent
- roof: converges toward a high internal point
- window rows: remain mostly parallel

This controlled contradiction is desirable.

---

# Front-Located Vanishing Logic

Some depth edges may visually imply a vanishing point located in front of or very close to
the object.

This may cause:

- rear edges to spread outward
- depth to feel compressed
- surfaces to appear to unfold toward the viewer
- a building to feel both diagrammatic and spatial at once

Use this as a deliberate structural choice, not random deformation.

---

# Distortion Limits

Perspective distortion should remain controlled.

Avoid:

- melting geometry
- surreal organic warping
- extreme fisheye distortion
- random twisting
- broken object connectivity
- impossible overlaps that destroy recognition
- arbitrary cubist fragmentation
- heavy dreamlike distortion

The drawing should still feel constructed.

---

# Phase 4 — Preserve Structural Rhythm

Repeated elements should remain visible but simplified.

Examples:

- windows
- columns
- doors
- vents
- drawers
- shelf bays
- wheels
- roof ribs
- facade panels

Rules:

- repeat approximately
- allow slight size differences
- allow slight spacing irregularity
- avoid perfect digital repetition
- do not reproduce every tiny variation from the photograph
- allow the rhythm to participate in the unconventional perspective

For example, a row of windows may grow slightly toward the back rather than shrink.

---

# Phase 5 — Compose the Image

## Default Composition

Prefer:

- one dominant subject
- centered or slightly offset placement
- generous negative space
- minimal background
- visible paper around the object
- stable overall silhouette

The object may fill roughly 55–80% of the canvas depending on its shape.

Do not automatically crop tightly.

## Background

Preferred:

- blank off-white paper
- pale warm paper
- faintly gray paper
- minimal ground line
- sparse construction marks
- very faint environmental hints only when needed

Avoid:

- fully rendered skies
- photoreal streets
- busy vegetation
- realistic room clutter
- dramatic scenery
- detailed atmospheric backgrounds

Unless the user specifically asks to preserve the environment, isolate the subject.

---

# Phase 6 — Drawing Language

The drawing should look physically made.

Use:

- graphite-like contour lines
- colored-pencil fills
- hand-drawn hatching
- visible measuring marks
- construction lines
- alignment guides
- extension lines
- double-drawn contours
- slightly uneven line weight
- occasional redrawn edges
- tiny registration errors
- faint erased marks

## Line Behavior

Lines should:

- wobble slightly
- vary subtly in pressure
- sometimes overlap
- occasionally stop just short
- occasionally extend slightly past corners
- feel deliberate but handmade

Avoid:

- perfectly uniform vector outlines
- digitally smooth Bézier curves
- razor-sharp CAD edges
- heavy comic-book ink
- thick marker outlines

---

# Construction Lines

Construction lines are a key part of the visual language.

Include some of the following when appropriate:

- extended roof lines
- facade alignment lines
- projected window guides
- center axes
- bounding-box traces
- perspective rays
- measuring marks
- faint erased alternatives
- vertical alignment extensions

Construction lines should remain lighter than final contours.

Do not cover the entire page with guides.

Their role is to reveal how the image was built.

---

# Phase 7 — Detail Reduction

Prefer structural information over decorative information.

## Buildings

Usually omit or simplify:

- brick-by-brick texture
- detailed mortar
- small signage
- reflections in glass
- tiny facade hardware
- decorative trim repetition
- individual roof tiles unless visually essential
- street clutter

## Vehicles

Usually omit or simplify:

- logos
- fine grille patterns
- tiny lights
- panel seams
- complex wheel spokes
- reflections
- license plate detail

## Furniture

Usually omit or simplify:

- fabric weave
- wood grain detail
- stitching
- screws
- small hardware
- glossy reflections

## General Objects

Usually omit:

- tiny labels
- serial numbers
- microtexture
- incidental scratches
- photographic reflections

Keep only details that contribute to identity, scale, rhythm, or structure.

---

# Phase 8 — Shading

Lighting should describe form without becoming realistic.

Prefer:

- graphite hatching
- colored-pencil shading
- soft tonal blocking
- broad flat values
- sparse cross-hatching
- gently darkened side planes
- slightly denser pencil on recessed regions

Avoid:

- cinematic lighting
- dramatic spotlighting
- ray-traced shadows
- glossy highlights
- high-contrast reflections
- realistic ambient occlusion
- HDR appearance
- physically accurate bounce light
- photographic depth of field

## Shadow Rule

If cast shadows are used:

- keep them simple
- keep them light
- treat them as graphic shapes
- do not make them the visual focus

---

# Phase 9 — Color System

Choose one of two color modes unless the user specifies a palette.

## Mode A — Muted Contrast

Use approximately 2–4 dominant colors.

Color qualities:

- low saturation
- dusty
- gray-shifted
- matte
- pencil-like
- slightly uneven
- softly layered

Good palette families include:

- sage green + warm brick red + graphite
- dusty blue + muted ochre + gray
- olive + subdued red + charcoal
- pale mint + faded rust + graphite
- blue-gray + warm brown + cream
- muted teal + dusty coral + soft gray
- moss + clay + off-white
- faded burgundy + slate + warm gray

Do not use all colors equally.

Prefer one dominant color, one supporting color, and graphite/neutral structure.

## Mode B — Monochrome

Use:

- graphite only
- charcoal-gray pencil
- one muted hue with tonal variation
- warm gray
- cool gray
- faded blue-gray
- muted brown-gray

Preserve the paper color as part of the palette.

---

# Color Application

Color should:

- sit inside broad planes
- remain imperfect
- show pencil grain
- vary slightly in density
- leave occasional paper showing through
- avoid smooth digital gradients

Color should not:

- look airbrushed
- look glossy
- look neon
- become highly saturated
- reproduce exact photographic materials

The goal is interpreted color, not sampled color.

---

# Phase 10 — Material and Surface Feel

Simulate traditional drawing materials.

Desired qualities:

- visible paper tooth
- graphite grain
- colored-pencil grain
- subtle uneven fill
- faint smudging
- light erasure traces
- occasional overlap marks
- paper-colored gaps inside fills

Avoid:

- artificial film grain
- digital noise overlays
- plastic texture
- hyperreal paper damage
- watercolor blooms
- thick impasto
- oil-paint texture
- glossy digital brushwork

---

# Phase 11 — Environmental Reduction

If a photograph contains a large environment around the subject:

1. identify whether the environment is essential to understanding the subject
2. remove most incidental scenery
3. preserve only major contextual planes when necessary
4. convert those planes into faint linework
5. keep the subject visually dominant

Example:

A building photographed on a street may retain:

- a faint sidewalk line
- a simple neighboring wall edge
- one ground reference

But should usually omit:

- parked cars
- street signs
- pedestrians
- dense foliage
- sky detail
- photographic shadows

unless requested.

---

# Phase 12 — Image Transformation Behavior

When an image-generation or image-editing tool is available:

1. use the uploaded image as the structural reference
2. preserve the subject identity
3. apply this visual system directly
4. do not replace the subject with a generic object of the same category
5. do not invent major structural features unless needed to resolve occlusion
6. keep the final result visually coherent and hand-drawn

When no image-generation or image-editing tool is available:

1. analyze the image
2. produce a detailed transformation prompt based on this skill
3. tailor the prompt to the specific subject
4. include the detected geometry, perspective distortions, palette choice, and detail
   reductions
5. clearly state that the prompt is ready for an image-capable model

---

# Strength Controls

If the user gives no preference, use the default values below.

## Perspective Distortion

Default: medium-subtle

### Low
- mostly recognizable conventional structure
- small divergence in selected planes
- gentle near-small/far-large effects
- minimal conflicting vanishing logic

### Medium
- clear plane independence
- visible unconventional convergence
- moderate depth inversion
- controlled scale contradiction

### High
- strong conflicting projection systems
- obvious near-small/far-large relationships
- visibly unfolding or expanding planes
- still preserve subject identity

## Detail

Default: simplified

### Minimal
- only dominant masses and essential openings

### Simplified
- dominant masses + recognizable repeated elements

### Detailed
- preserve more secondary structure but still avoid photographic microdetail

## Construction Lines

Default: visible but restrained

### Light
- only a few faint guides

### Medium
- clearly visible alignment and projection marks

### Strong
- numerous construction traces, still secondary to the object

## Color

Default: muted contrast

Possible values:

- muted contrast
- monochrome graphite
- monochrome colored pencil
- custom palette from user

---

# Automatic Decisions

When the user uploads an image without specifying options:

1. choose medium-subtle perspective distortion
2. choose simplified detail
3. use restrained construction lines
4. isolate the primary subject
5. choose a muted 2–3 color palette based loosely on the source image
6. reduce saturation substantially
7. keep the background mostly blank
8. preserve paper texture
9. retain essential repeated elements
10. avoid realistic shadows and reflections

---

# Source-Color Interpretation

Do not simply copy source colors.

Instead:

1. identify the source image's dominant warm/cool relationships
2. reduce the palette to 2–4 colors
3. lower saturation
4. move colors slightly toward gray
5. preserve contrast through hue and value rather than saturation
6. use graphite or charcoal as the structural neutral

If the source is visually chaotic, simplify further rather than preserving every color.

---

# Perspective Design Recipes

Use these recipes as starting structures.

## Recipe A — Expanding Depth

Good for:

- buildings
- cabinets
- tables
- boxes
- vehicles

Behavior:

- front plane remains stable
- one side plane widens slightly toward the rear
- depth lines diverge
- repeated elements grow subtly with distance

## Recipe B — Independent Facades

Good for:

- architecture
- furniture
- appliances

Behavior:

- front plane nearly orthographic
- side plane converges unusually
- top/roof plane uses a separate vanishing direction
- verticals remain mostly stable

## Recipe C — Compressed Model

Good for:

- large buildings
- industrial structures
- vehicles

Behavior:

- depth is shortened
- distant planes remain relatively large
- overlapping masses feel stacked
- overall subject resembles a hand-built model

## Recipe D — Unfolded Plane

Good for:

- interiors
- furniture
- machinery
- architecture

Behavior:

- one plane rotates slightly toward the viewer
- adjacent plane remains in another projection
- the object appears simultaneously spatial and diagrammatic

## Recipe E — Mixed Orthographic Perspective

Good for:

- tools
- appliances
- furniture
- simple vehicles

Behavior:

- one major face is nearly flat elevation
- one side reveals depth
- top surface uses shallow perspective
- no single vanishing point governs all faces

Do not apply every recipe simultaneously.

Choose one primary recipe and optionally one secondary recipe.

---

# Recognizability Safeguards

Always preserve:

- overall silhouette
- number and relationship of major masses
- key openings
- major asymmetries
- category-defining features
- orientation
- distinctive roof/body shape
- repeated structural rhythm when recognizable

Do not preserve:

- accidental photographic distortion
- lens blur
- reflections
- clutter
- irrelevant background detail

---

# Negative Prompts / Avoidance Rules

Avoid outputs that resemble:

- photorealistic renders
- polished concept art
- anime
- comic-book inking
- watercolor illustration
- oil painting
- 3D CGI
- CAD screenshots
- architectural visualization renders
- glossy product photography
- cyberpunk aesthetics
- neon palettes
- dramatic movie lighting
- surreal melting forms
- extreme fisheye photography
- dense cross-hatching that obscures geometry
- perfectly clean vector diagrams

Avoid excessive:

- saturation
- texture
- ornament
- realism
- environmental detail
- atmospheric effects
- depth of field
- reflections
- shadows

---

# Prompt Construction Template

When converting these rules into an image-editing prompt, structure the prompt in this
order:

1. identify the exact subject from the uploaded image
2. preserve its recognizable silhouette and major structural features
3. simplify it into geometric masses
4. specify the chosen perspective recipe
5. describe any near-small/far-large relationship
6. specify hand-drawn graphite line quality
7. request visible but restrained construction lines
8. specify colored-pencil or monochrome treatment
9. specify low saturation
10. specify paper texture
11. reduce fine detail
12. isolate the subject with generous negative space
13. explicitly reject photorealistic rendering

Example structure:

> Reinterpret the uploaded [subject] as a hand-drawn observational architectural study.
> Preserve its recognizable silhouette, major masses, openings, and repeated structural
> elements. Simplify complex surfaces into boxes, prisms, wedges, and flat planes.
> Reconstruct the perspective using [recipe], allowing adjacent faces to follow slightly
> different projection systems. Let selected distant elements remain equal in size or
> become subtly larger than nearer ones. Draw with slightly uneven graphite-like contours,
> faint construction lines, alignment marks, and colored-pencil fills. Use a restrained
> low-saturation palette of [colors], visible paper grain, minimal realistic shading, and
> generous blank space. Remove incidental background detail, reflections, photographic
> texture, and cinematic lighting.

Tailor every bracketed field to the actual image.

---

# User Preference Handling

If the user specifies a preference, obey it unless it destroys subject recognition.

Examples:

- "More distorted" → increase perspective strength one level
- "Less distorted" → reduce perspective strength
- "Only graphite" → use monochrome mode
- "Green and red" → use low-saturation green/red contrast
- "Keep the background" → simplify the background rather than removing it
- "More construction lines" → increase guide visibility
- "Cleaner drawing" → reduce wobble and construction marks, but keep handmade character
- "More naive" → increase proportion irregularity and line imperfection without making the
  object childish or incoherent
- "More architectural" → emphasize plane logic, alignment lines, repeated modules, and
  measured structure

---

# Final Quality Check

Before finalizing the output, verify every item below.

## Identity

- Is the source subject immediately recognizable?
- Are its main structural relationships preserved?
- Does it still read as the same specific object or building rather than a generic one?

## Perspective

- Is the perspective intentionally reconstructed?
- Are at least some planes freed from a single conventional vanishing system?
- Is the spatial contradiction controlled?
- Does the object remain coherent?

## Geometry

- Have unnecessary curves and details been simplified?
- Are dominant planes and masses clear?
- Are repeated elements handled as rhythm rather than microdetail?

## Drawing

- Do the lines feel handmade?
- Are there subtle construction traces?
- Are outlines slightly imperfect without becoming messy?

## Color

- Is the palette restrained?
- Is saturation low?
- Are there no more colors than necessary?
- Does the paper remain visually present?

## Light and Texture

- Is shading descriptive rather than cinematic?
- Are reflections minimized?
- Is paper/pencil texture visible?
- Does the image avoid a digital-rendered finish?

## Composition

- Is the subject dominant?
- Is there enough negative space?
- Has background clutter been reduced?

If most of these conditions are satisfied, the transformation is successful.

---

# Short Invocation Guidance

Use this skill when prompts include intentions such as:

- transform this building photo into a hand-drawn architectural sketch
- redraw this object with strange perspective
- make the far side larger than the near side
- use conflicting vanishing points
- create an observational pencil drawing
- simplify this photo into geometric forms
- render this object with muted colored pencil
- turn this image into a diagrammatic hand-drawn study
- create an intentionally incorrect but coherent perspective drawing

Do not use this skill for ordinary photo enhancement, realistic rendering, standard
perspective correction, or generic sketch filters.
